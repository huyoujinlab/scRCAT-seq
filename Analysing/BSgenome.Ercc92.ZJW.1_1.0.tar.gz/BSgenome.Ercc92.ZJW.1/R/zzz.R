###
###

.pkgname <- "BSgenome.Ercc92.ZJW.1"

.seqnames <- c("ERCC-00002","ERCC-00003","ERCC-00004","ERCC-00009","ERCC-00012","ERCC-00013","ERCC-00014","ERCC-00016","ERCC-00017","ERCC-00019","ERCC-00022","ERCC-00024","ERCC-00025","ERCC-00028","ERCC-00031","ERCC-00033","ERCC-00034","ERCC-00035","ERCC-00039","ERCC-00040","ERCC-00041","ERCC-00042","ERCC-00043","ERCC-00044","ERCC-00046","ERCC-00048","ERCC-00051","ERCC-00053","ERCC-00054","ERCC-00057","ERCC-00058","ERCC-00059","ERCC-00060","ERCC-00061","ERCC-00062","ERCC-00067","ERCC-00069","ERCC-00071","ERCC-00073","ERCC-00074","ERCC-00075","ERCC-00076","ERCC-00077","ERCC-00078","ERCC-00079","ERCC-00081","ERCC-00083","ERCC-00084","ERCC-00085","ERCC-00086","ERCC-00092","ERCC-00095","ERCC-00096","ERCC-00097","ERCC-00098","ERCC-00099","ERCC-00104","ERCC-00108","ERCC-00109","ERCC-00111","ERCC-00112","ERCC-00113","ERCC-00116","ERCC-00117","ERCC-00120","ERCC-00123","ERCC-00126","ERCC-00130","ERCC-00131","ERCC-00134","ERCC-00136","ERCC-00137","ERCC-00138","ERCC-00142","ERCC-00143","ERCC-00144","ERCC-00145","ERCC-00147","ERCC-00148","ERCC-00150","ERCC-00154","ERCC-00156","ERCC-00157","ERCC-00158","ERCC-00160","ERCC-00162","ERCC-00163","ERCC-00164","ERCC-00165","ERCC-00168","ERCC-00170","ERCC-00171")

.circ_seqs <- NULL

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="ERCC92",
        common_name="ERCC92",
        provider="ZJW",
        provider_version="1",
        release_date="2019",
        release_name="ERCC92",
        source_url="ftp://ftp.jcvi.org/pub/data/m_truncatula/Mt4.0/Assembly/JCVI.Medtr.v4.20130313.fasta",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Ercc92"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

